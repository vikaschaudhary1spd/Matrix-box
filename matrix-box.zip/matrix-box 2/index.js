import { createRoot } from 'https://cdn.skypack.dev/react-dom';
import App from '../App.js';

const root = createRoot(document.getElementById('root'));
root.render(<App />);