const App = () => {
    const { useState } = React;
    const [grid, setGrid] = useState(
      Array(9).fill({ color: 'bg-white', clicked: false })
    );
    const [clickOrder, setClickOrder] = React.useState([]);
  
    const handleClick = (index) => {
      if (grid[index].clicked) return;
  
      if (index === 8 && clickOrder.length > 0) {
        startOrangeSequence();
        return;
      }
  
      setGrid(prevGrid => {
        const newGrid = [...prevGrid];
        newGrid[index] = { ...newGrid[index], color: 'bg-green-500', clicked: true };
        return newGrid;
      });
  
      setClickOrder(prevOrder => [...prevOrder, index]);
    };
  
    const startOrangeSequence = () => {
      let delay = 0;
      clickOrder.forEach((boxIndex) => {
        setTimeout(() => {
          setGrid(prevGrid => {
            const newGrid = [...prevGrid];
            newGrid[boxIndex] = { ...newGrid[boxIndex], color: 'bg-orange-500' };
            return newGrid;
          });
        }, delay);
        delay += 300;
      });
    };
  
    return (
      <div className="p-4">
        <h1 className="text-2xl font-bold mb-4 text-center">3x3 Matrix Game</h1>
        <div className="grid grid-cols-3 gap-2 w-fit mx-auto">
          {grid.map((cell, index) => (
            <div
              key={index}
              className={`w-24 h-24 rounded-lg shadow-md transition-colors duration-300 cursor-pointer ${cell.color} ${
                index === 8 ? 'border-2 border-gray-400' : ''
              }`}
              onClick={() => handleClick(index)}
            />
          ))}
        </div>
      </div>
    );
  };
  
  export default App;