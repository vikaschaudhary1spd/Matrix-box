app.get("/orders", async (req, res) => {
    try {
      const { page = 1, limit = 10 } = req.query;
      const offset = (page - 1) * limit;
      const cacheKey = `orders_page_${page}_limit_${limit}`;
  
      redisClient.get(cacheKey, async (err, cachedData) => {
        if (cachedData) {
          return res.json(JSON.parse(cachedData));
        }
        
        const [orders] = await pool.execute(
          "SELECT id, user_id, total_price, created_at FROM orders ORDER BY created_at DESC LIMIT ? OFFSET ?",
          [parseInt(limit), parseInt(offset)]
        );
        
        redisClient.setex(cacheKey, 3600, JSON.stringify(orders));
        res.json(orders);
      });
    } catch (error) {
      console.error("Database error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });