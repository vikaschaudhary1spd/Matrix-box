import React, { useState } from 'react';
import './App.css';

const App = () => {
  const [matrix, setMatrix] = useState(Array(3).fill(Array(3).fill(null)));
  const [clickedOrder, setClickedOrder] = useState([]);

  const handleClick = (row, col) => {
    if (row === 2 && col === 2) {
      
      const newMatrix = matrix.map((r, i) =>
        r.map((cell, j) => {
          if (clickedOrder.includes(`${i}-${j}`)) {
            return 'orange';
          }
          return cell;
        })
      );
      setMatrix(newMatrix);
    } else {
      
      const newMatrix = [...matrix];
      newMatrix[row][col] = 'green';
      setMatrix(newMatrix);
      setClickedOrder([...clickedOrder, `${row}-${col}`]);
    }
  };

  return (
    <div className="matrix">
      {matrix.map((row, rowIndex) => (
        <div key={rowIndex} className="row">
          {row.map((cell, colIndex) => (
            <div
              key={colIndex}
              className="box"
              style={{ backgroundColor: cell || 'lightgray' }}
              onClick={() => handleClick(rowIndex, colIndex)}
            />
          ))}
        </div>
      ))}
    </div>
  );
};

export default App;